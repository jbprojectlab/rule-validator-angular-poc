export const environment = {
  production: true,
  host: 'http://mdcdappl2r05lv.bcbsa.com:8085'
};
