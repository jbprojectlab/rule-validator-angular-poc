export const environment = {
    production: false,
    host: 'http://mdcdappl2r05lv.bcbsa.com:8085'
}
