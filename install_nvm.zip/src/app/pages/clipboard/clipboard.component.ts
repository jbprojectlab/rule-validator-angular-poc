import { Component } from '@angular/core';

@Component({
  selector: 'app-clipboard',
  templateUrl: './clipboard.component.html',
  styleUrls: ['./clipboard.component.sass']
})
export class ClipboardComponent  {

  constructor() { }

}
